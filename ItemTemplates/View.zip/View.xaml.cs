using $rootnamespace$.ViewModel;

namespace $rootnamespace$;

public partial class $safeitemname$ : ContentPage
{
    private readonly $safeitemname$ViewModel _viewModel;

    public $safeitemname$($safeitemname$ViewModel viewModel)
	{
		InitializeComponent();
        _viewModel = ViewModel;
        BindingContext = _viewModel;
    }
}