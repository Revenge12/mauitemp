﻿using $rootnamespace$.ViewModel
using $rootnamespace$.Services

namespace $rootnamespace$.ViewModel
{
    public partial class $safeitemname$ : BaseViewModel
    {
	
        public $safeitemname$()
        {

        }
    }
}
