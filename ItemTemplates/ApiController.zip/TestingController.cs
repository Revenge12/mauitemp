﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Server.Template.Data;
using Server.Template.Services;
using Shared.Template.Database;

namespace $rootnamespace$
{
    [Route("api/[controller]")]
    [ApiController]
    public class $safeitemname$ : ControllerBase
    {
        private readonly MainDbContext _context;

        public $safeitemname$(MainDbContext context)
        {
            _context = context;
        }

        [HttpPost("upsert")]
        public async Task<IActionResult> Upsert(Test test)
        {
            var generic = new GenericDataService<Test>(_context);

            var resposne = await generic.GenericUpdateInsert(test);

            return Ok(resposne);
        }

        [HttpPost("remove")]
        public async Task<IActionResult> Remove(Test test)
        {
            var generic = new GenericDataService<Test>(_context);

            var resposne = await generic.GenericUpdateInsert(test);

            return Ok(resposne);
        }
    }
}
